# Who-s-at-the-Door
Amazon Alexa and Raspberry Pi project that allows a user to know who is exactly is knocking at their door using facial recognition

Checkout the project at https://www.hackster.io/gmelaub/alexa-who-s-at-the-door-d0f6b5
